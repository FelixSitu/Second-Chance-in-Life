from sys import argv


for idx,arg in enumerate(argv):
    print idx,arg

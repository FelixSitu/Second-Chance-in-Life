def print_examples():

   # place the print calls specified in the lab description below here


    print "Entered print_examples function.\n"
    n = 10
    m = 20
    f = 30
    print "n:",n
    n = 99
    print "n:",n,"\tm:",m
    print "f:",f

if __name__ == '__main__':
   print_examples()
